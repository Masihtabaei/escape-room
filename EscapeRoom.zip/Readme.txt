Ein neues Rätsel wird hinzugefügt, indem im Game-Konstruktor ein neues Riddle-Object deklariert  wird.
Anschließend muss das Rätsel der dem Escaperoom entsprechenden Riddlelist hinzugefügt werden.
Das Spiel wird über die GameTest.java (Klasse) gestartet.