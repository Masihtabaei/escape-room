package escapeRoom.GameLogic;

public class GameTest {
	public static void main(String[] args) {
		Game game = new Game("Gruppe 4");
	}
}
