package escapeRoom.UserInterface.GUI;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.event.ActionListener;

public class StartFrame extends JFrame {

	private static final long serialVersionUID = 7829708358863586653L;
	private JPanel contentPane;
	private JLabel label;
	private JButton playButton, exitButton;

	public StartFrame(String title) {

		contentPane = new JPanel();
		contentPane.setLayout(null);

		setTitle(title);
		setSize(300, 300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setContentPane(contentPane);

		setVisible(true);

	}

	public void appendLabel(String text) {
		label = new JLabel();
		label.setBounds(69, 29, 143, 50);
		label.setHorizontalAlignment(JLabel.CENTER);
		label.setFont(new Font("Segoe UI Black", Font.BOLD, 14));

		contentPane.add(label);
	}

	public void appendButtons(ActionListener playButtonActionListener, ActionListener exitButtonActionListener) {
		playButton = new JButton("Play");
		playButton.setBounds(69, 109, 143, 23);
		playButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		playButton.setFocusable(false);

		exitButton = new JButton("Exit");
		exitButton.setBounds(69, 159, 143, 23);
		exitButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		exitButton.setFocusable(false);

		contentPane.add(playButton);
		contentPane.add(exitButton);
	}

}
