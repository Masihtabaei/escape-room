package escapeRoom.UserInterface.GUI;

import java.util.List;

import javax.swing.JFrame;

import escapeRoom.GameLogic.EscapeRoom;
import escapeRoom.GameLogic.InvalidInputException;
import escapeRoom.GameLogic.Riddle;
import escapeRoom.UserInterface.UserInterface;

public class InOut implements UserInterface {
	private StartFrame startFrame;
	private LoginFrame loginFrame;
	private EscapeRoomFrame escapeRoomFrame;
	private EscapeRoomsFrame escapeRoomsFrame;
	private EndFrame EndFrame;

	@Override
	public void showTheTitle(String title) {
		startFrame = new StartFrame(title);
		startFrame.appendLabel(title);
		startFrame.appendButtons(null, null);

	}

	@Override
	public String promptForStartOrExit() {
		return null;
	}

	@Override
	public String promptForTeamname() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void showAnError(String message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void showTheEscapeRooms(List<EscapeRoom> escapeRooms) {
		// TODO Auto-generated method stub

	}

	@Override
	public int promptForEscapeRoom() throws InvalidInputException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void showTheRiddle(Riddle riddle) {
		// TODO Auto-generated method stub

	}

	@Override
	public String promptForAnswer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void showTheResultOfAnAttempt(String message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void showTheResultOfTheEscapeRoom(String message) {
		// TODO Auto-generated method stub

	}

	@Override
	public void showTheFinalPassword(String finalPassword) {
		System.out.println("Final Password:" + finalPassword);
	}

}
