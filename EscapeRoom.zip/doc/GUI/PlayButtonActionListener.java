package escapeRoom.UserInterface.GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PlayButtonActionListener implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
	
	}

}
