package escapeRoom.UserInterface.GUI;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.ImageIcon;
import java.awt.Font;

public class EndFrame extends JFrame {


	private static final long serialVersionUID = -5735349467444223692L;
	private JPanel contentPane;
	private JLabel escapeRoomStatusTextLabel;
	private JLabel escapeRoomStatusIconLabel;

	public EndFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		contentPane = new JPanel();
		setContentPane(contentPane);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWeights = new double[]{0.0};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0};
		contentPane.setLayout(gridBagLayout);
		
		/*
		 * 
		 * Attributes (Links) to icons for escape room status label
		 * <a href="https://www.flaticon.com/free-icons/game-over" title="game over icons">Game over icons created by Freepik - Flaticon</a>
		 * <a href="https://www.flaticon.com/free-icons/congratulation" title="congratulation icons">Congratulation icons created by Freepik - Flaticon</a>
		 * 
		 * 
		 */
		escapeRoomStatusIconLabel = new JLabel();
		escapeRoomStatusIconLabel.setIcon(new ImageIcon("C:\\Users\\masih\\Downloads\\congratulation.png"));
		GridBagConstraints gridBagConstraintsForLabel = new GridBagConstraints();
		gridBagConstraintsForLabel.insets = new Insets(0, 0, 5, 0);
		gridBagConstraintsForLabel.gridx = 0;
		gridBagConstraintsForLabel.gridy = 0;
		contentPane.add(escapeRoomStatusIconLabel, gridBagConstraintsForLabel);
		
		
		escapeRoomStatusTextLabel = new JLabel("Impressive :) You escaped successfully!");
		escapeRoomStatusTextLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
		
		GridBagConstraints gridBagConstraintsForTextField = new GridBagConstraints();
		gridBagConstraintsForTextField.insets = new Insets(0, 0, 5, 0);
		gridBagConstraintsForTextField.gridx = 0;
		gridBagConstraintsForTextField.gridy = 1;
		contentPane.add(escapeRoomStatusTextLabel, gridBagConstraintsForTextField);
		
		setVisible(true);
	}

}
