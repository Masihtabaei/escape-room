package escapeRoom.UserInterface.GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;

public class EscapeRoomFrame extends JFrame {

	private static final long serialVersionUID = 2221384022922914427L;
	private JPanel contentPane, headerPanel, contentPanel, footerPanel, infoBoxPanel, finalPasswordBoxPanel;
	private JLabel teamNameLabel, leftChancesLabel, finalPasswordLabel;
	private JTextField finalPasswordTextField, answerTextField;
	private JScrollPane riddleScrollPane;
	private JTextArea riddleTextArea;
	private JButton checkAnswerButton;

	public EscapeRoomFrame() {
		setTitle("Escape Room - Game");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 500);
		setMinimumSize(new Dimension(450, 300));
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		appendHeaderPanel();
		appendContentPanel();
		appendFooterPanel();

		setVisible(true);
		answerTextField.requestFocusInWindow();

	}

	public void updateRiddleTextAreaText(String text) {
		riddleTextArea.setText(text);
	}

	public String getAnswerTextFieldText() {
		return answerTextField.getText();
	}

	public void resetAnswerTextFieldText() {
		answerTextField.setText("");
	}

	public void showTheMessage(String message) {
		JOptionPane.showMessageDialog(this, message);
	}

	public void updateChancesLeft(int chancesLeft) {
		leftChancesLabel.setText("Left Chances: " + String.valueOf(chancesLeft));
	}

	public void updateFinalPasswort(String disclosedString) {
		finalPasswordTextField.setText(disclosedString);
	}

	private void appendHeaderPanel() {
		headerPanel = new JPanel();
		headerPanel.setLayout(new BorderLayout(5, 5));
		headerPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.add(headerPanel, BorderLayout.NORTH);

		appendInfoBox();
		appendFinalPasswortBox();
	}

	private void appendInfoBox() {
		infoBoxPanel = new JPanel();
		infoBoxPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		infoBoxPanel.setBackground(Color.LIGHT_GRAY);
		infoBoxPanel.setLayout(new GridLayout(2, 1));

		appendLabelsInInfoBox();

		headerPanel.add(infoBoxPanel, BorderLayout.WEST);
	}

	private void appendLabelsInInfoBox() {
		teamNameLabel = new JLabel("Team-Name: <dynamic>");
		teamNameLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 11));
		teamNameLabel.setForeground(Color.WHITE);

		leftChancesLabel = new JLabel("Left Chances: <dynamic>");
		leftChancesLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 11));
		leftChancesLabel.setForeground(Color.WHITE);

		infoBoxPanel.add(teamNameLabel);
		infoBoxPanel.add(leftChancesLabel);
	}

	private void appendFinalPasswortBox() {
		finalPasswordBoxPanel = new JPanel();
		finalPasswordBoxPanel.setBackground(Color.LIGHT_GRAY);
		finalPasswordBoxPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		appendLabelInFinalPasswortBox();
		appendTextFieldInFinalPasswortBox();

		headerPanel.add(finalPasswordBoxPanel, BorderLayout.CENTER);
	}

	private void appendLabelInFinalPasswortBox() {
		finalPasswordLabel = new JLabel("Final Password: ");
		finalPasswordLabel.setHorizontalAlignment(SwingConstants.LEFT);
		finalPasswordLabel.setForeground(Color.WHITE);
		finalPasswordLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 11));

		finalPasswordBoxPanel.add(finalPasswordLabel);
	}

	private void appendTextFieldInFinalPasswortBox() {
		finalPasswordTextField = new JTextField("<dynamic>");
		// finalPasswordTextField.setColumns(disclosedCharacters.length());
		finalPasswordTextField.setHorizontalAlignment(SwingConstants.CENTER);
		finalPasswordTextField.setFont(new Font("Segoe UI", Font.BOLD, 14));
		finalPasswordTextField.setEditable(false);

		finalPasswordBoxPanel.add(finalPasswordTextField);
	}

	private void appendContentPanel() {
		contentPanel = new JPanel();
		contentPanel.setBackground(Color.GREEN);
		contentPanel.setLayout(new BorderLayout(0, 0));
		contentPane.add(contentPanel, BorderLayout.CENTER);

		appendRiddleScrollPane();
	}

	private void appendRiddleScrollPane() {
		riddleScrollPane = new JScrollPane();
		riddleScrollPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPanel.add(riddleScrollPane);

		appendTextAreaInRiddleScrollPane();
	}

	private void appendTextAreaInRiddleScrollPane() {
		riddleTextArea = new JTextArea("<dynamic>");
		riddleTextArea.setLineWrap(true);
		riddleTextArea.setCaretPosition(0);
		riddleTextArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		riddleTextArea.setEditable(false);
		riddleTextArea.setWrapStyleWord(true);
		riddleScrollPane.setViewportView(riddleTextArea);
	}

	private void appendFooterPanel() {
		footerPanel = new JPanel();
		footerPanel.setLayout(new BorderLayout(10, 10));
		footerPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		footerPanel.setBackground(new Color(240, 240, 240, 240));
		contentPane.add(footerPanel, BorderLayout.SOUTH);

		appendAnswerTextFieldInFooterPanel();
		appendCheckAnswerButtonInFooterPanel();
	}

	private void appendAnswerTextFieldInFooterPanel() {
		answerTextField = new JTextField();
		answerTextField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		footerPanel.add(answerTextField, BorderLayout.CENTER);

	}

	private void appendCheckAnswerButtonInFooterPanel() {
		checkAnswerButton = new JButton("Check My Answer");
		checkAnswerButton.setForeground(Color.WHITE);
		checkAnswerButton.setBackground(Color.BLUE);
		checkAnswerButton.setFont(new Font("Segoe UI Black", Font.BOLD, 11));
		footerPanel.add(checkAnswerButton, BorderLayout.EAST);
	}

	public static void main(String[] args) {
		new EscapeRoomFrame();
	}

}
