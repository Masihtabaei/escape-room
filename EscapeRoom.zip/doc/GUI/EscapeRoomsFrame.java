package escapeRoom.UserInterface.GUI;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JList;
import java.awt.BorderLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ListSelectionModel;

public class EscapeRoomsFrame extends JFrame {

	private static final long serialVersionUID = 5888982955142281414L;
	private JPanel contentPane;

	public EscapeRoomsFrame() {

		setSize(600, 500);
		setMinimumSize(new Dimension(450, 300));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(20, 20));

		appendTheWelcomePanelAndLabel();
		appendTheEscapeRoomsPanelAndList();
		appendTheStartTheGamePanelAndButton();

		this.setVisible(true);
	}

	private void appendTheWelcomePanelAndLabel() {
		JPanel welcomeLabelPanel = new JPanel();
		// panel.setBorder(new EmptyBorder(10,10,0,10));
		contentPane.add(welcomeLabelPanel, BorderLayout.NORTH);

		JLabel welcomeLabel = new JLabel("Welcome <dynamic>");
		welcomeLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
		welcomeLabelPanel.add(welcomeLabel);

	}

	private void appendTheEscapeRoomsPanelAndList() {
		JPanel escapeRoomsPanel = new JPanel();
		@SuppressWarnings("rawtypes")
		JList escapeRoomsList = new JList();
		escapeRoomsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		escapeRoomsPanel.setLayout(new BorderLayout(0, 0));
		escapeRoomsPanel.setBorder(new EmptyBorder(0, 50, 0, 50));
		escapeRoomsPanel.add(escapeRoomsList);
		contentPane.add(escapeRoomsPanel, BorderLayout.CENTER);

	}

	private void appendTheStartTheGamePanelAndButton() {
		JPanel startTheGameButtonPanel = new JPanel();
		contentPane.add(startTheGameButtonPanel, BorderLayout.SOUTH);
		startTheGameButtonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JButton startTheGameButton = new JButton("Start your Adventure");
		startTheGameButton.setBackground(new Color(0, 0, 255));
		startTheGameButton.setForeground(new Color(255, 255, 255));
		startTheGameButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
		startTheGameButtonPanel.add(startTheGameButton);

	}

}
