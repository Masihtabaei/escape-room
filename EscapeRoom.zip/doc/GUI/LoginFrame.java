package escapeRoom.UserInterface.GUI;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.Font;
import java.awt.Color;

public class LoginFrame extends JFrame {

	private static final long serialVersionUID = -7314216966467910624L;
	private JPanel contentPane;
	private JButton letsGoButton;
	private JLabel instructionLabel, teamNameTextFieldLabel, teamNameExampleLabel;
	private JTextField teamNameTextField;

	public LoginFrame() {
		contentPane = new JPanel();
		contentPane.setLayout(null);

		setTitle("Escape Room - Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300, 300);
		setLocationRelativeTo(null);
		setContentPane(contentPane);

		appendLabels();
		appendTextField();
		appendButton();

		setVisible(true);
	}

	public String getNicknameTextFieldText() {
		return teamNameTextField.getText();
	}

	public void showTheError(String message) {
		JOptionPane.showMessageDialog(this, message);
	}

	private void appendTextField() {
		teamNameTextField = new JTextField();
		teamNameTextField.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		teamNameTextField.setBounds(33, 117, 218, 31);

		contentPane.add(teamNameTextField);
	}

	private void appendLabels() {
		instructionLabel = new JLabel("Please enter your team-name: ");
		instructionLabel.setBounds(31, 31, 221, 50);
		instructionLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 11));
		instructionLabel.setHorizontalAlignment(JLabel.CENTER);

		teamNameTextFieldLabel = new JLabel("Team-Name");
		teamNameTextFieldLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		teamNameTextFieldLabel.setBounds(112, 92, 60, 25);
		teamNameTextFieldLabel.setHorizontalAlignment(JLabel.CENTER);

		teamNameExampleLabel = new JLabel("e.g. bestOfBests");
		teamNameExampleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		teamNameExampleLabel.setBounds(90, 148, 104, 25);
		teamNameExampleLabel.setHorizontalAlignment(JLabel.CENTER);

		contentPane.add(instructionLabel);
		contentPane.add(teamNameTextFieldLabel);
		contentPane.add(teamNameExampleLabel);
	}

	private void appendButton() {
		letsGoButton = new JButton("Lets Go!");
		letsGoButton.setForeground(Color.WHITE);
		letsGoButton.setBounds(101, 203, 81, 30);
		letsGoButton.setBackground(new Color(0, 0, 205));
		letsGoButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));

		contentPane.add(letsGoButton);
	}

}
